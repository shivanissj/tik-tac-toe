import React, { useState, useEffect } from 'react';
import { RotateCcw, Trophy, Users } from 'lucide-react';

type Player = 'player1' | 'player2';
type CellValue = Player | null;
type Board = CellValue[];

interface GameState {
  board: Board;
  currentPlayer: Player;
  winner: Player | 'tie' | null;
  gameOver: boolean;
  scores: { player1: number; player2: number; ties: number };
}

interface TicTacToeProps {
  player1Emoji: string;
  player2Emoji: string;
}

const WINNING_COMBINATIONS = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
  [0, 4, 8], [2, 4, 6] // diagonals
];

export default function TicTacToe({ player1Emoji, player2Emoji }: TicTacToeProps) {
  const [gameState, setGameState] = useState<GameState>({
    board: Array(9).fill(null),
    currentPlayer: 'player1',
    winner: null,
    gameOver: false,
    scores: { player1: 0, player2: 0, ties: 0 }
  });

  const [winningCells, setWinningCells] = useState<number[]>([]);

  const checkWinner = (board: Board): { winner: Player | 'tie' | null; winningCells: number[] } => {
    // Check for winning combinations
    for (const combination of WINNING_COMBINATIONS) {
      const [a, b, c] = combination;
      if (board[a] && board[a] === board[b] && board[a] === board[c]) {
        return { winner: board[a] as Player, winningCells: combination };
      }
    }

    // Check for tie
    if (board.every(cell => cell !== null)) {
      return { winner: 'tie', winningCells: [] };
    }

    return { winner: null, winningCells: [] };
  };

  const handleCellClick = (index: number) => {
    if (gameState.board[index] || gameState.gameOver) return;

    const newBoard = [...gameState.board];
    newBoard[index] = gameState.currentPlayer;

    const { winner, winningCells: newWinningCells } = checkWinner(newBoard);
    
    setGameState(prev => ({
      ...prev,
      board: newBoard,
      currentPlayer: prev.currentPlayer === 'player1' ? 'player2' : 'player1',
      winner,
      gameOver: winner !== null,
      scores: winner 
        ? { 
            ...prev.scores, 
            [winner === 'tie' ? 'ties' : winner]: prev.scores[winner === 'tie' ? 'ties' : winner] + 1 
          }
        : prev.scores
    }));

    setWinningCells(newWinningCells);
  };

  const resetGame = () => {
    setGameState(prev => ({
      ...prev,
      board: Array(9).fill(null),
      currentPlayer: 'player1',
      winner: null,
      gameOver: false
    }));
    setWinningCells([]);
  };

  const resetScores = () => {
    setGameState(prev => ({
      ...prev,
      scores: { player1: 0, player2: 0, ties: 0 }
    }));
  };

  const getCurrentPlayerEmoji = () => {
    return gameState.currentPlayer === 'player1' ? player1Emoji : player2Emoji;
  };

  const getCellEmoji = (cellValue: CellValue) => {
    if (cellValue === 'player1') return player1Emoji;
    if (cellValue === 'player2') return player2Emoji;
    return '';
  };

  const getStatusMessage = () => {
    if (gameState.winner === 'tie') return "It's a tie! 🤝";
    if (gameState.winner) {
      const winnerEmoji = gameState.winner === 'player1' ? player1Emoji : player2Emoji;
      return `${winnerEmoji} wins! 🎉`;
    }
    return `${getCurrentPlayerEmoji()}'s turn`;
  };

  return (
    <div className="w-full max-w-md mx-auto">
      {/* Game Status */}
      <div className="text-center mb-6">
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg border border-white/20">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            {getStatusMessage()}
          </h2>
          {!gameState.gameOver && (
            <div className="flex items-center justify-center gap-2 text-sm text-gray-600">
              <Users size={16} />
              <span>Current player: {getCurrentPlayerEmoji()}</span>
            </div>
          )}
        </div>
      </div>

      {/* Game Board */}
      <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-xl border border-white/20 mb-6">
        <div className="grid grid-cols-3 gap-3">
          {gameState.board.map((cell, index) => (
            <button
              key={index}
              onClick={() => handleCellClick(index)}
              disabled={cell !== null || gameState.gameOver}
              className={`
                aspect-square bg-gradient-to-br from-gray-50 to-gray-100 
                rounded-2xl flex items-center justify-center text-4xl font-bold
                transition-all duration-200 shadow-md hover:shadow-lg
                border-2 border-transparent
                ${!cell && !gameState.gameOver 
                  ? 'hover:border-blue-300 hover:bg-gradient-to-br hover:from-blue-50 hover:to-indigo-50 hover:scale-105 cursor-pointer' 
                  : 'cursor-not-allowed'
                }
                ${winningCells.includes(index) 
                  ? 'bg-gradient-to-br from-green-100 to-emerald-100 border-green-300 scale-105' 
                  : ''
                }
                ${cell ? 'animate-bounce-once' : ''}
              `}
            >
              <span className={`transition-all duration-300 ${cell ? 'scale-100' : 'scale-0'}`}>
                {getCellEmoji(cell)}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Scoreboard */}
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg border border-white/20 mb-6">
        <div className="flex justify-between items-center text-center">
          <div className="flex-1">
            <div className="text-2xl mb-1">{player1Emoji}</div>
            <div className="text-2xl font-bold text-blue-600">{gameState.scores.player1}</div>
            <div className="text-xs text-gray-500">Player 1</div>
          </div>
          <div className="flex-1">
            <div className="text-2xl mb-1">🤝</div>
            <div className="text-2xl font-bold text-gray-600">{gameState.scores.ties}</div>
            <div className="text-xs text-gray-500">Ties</div>
          </div>
          <div className="flex-1">
            <div className="text-2xl mb-1">{player2Emoji}</div>
            <div className="text-2xl font-bold text-red-600">{gameState.scores.player2}</div>
            <div className="text-xs text-gray-500">Player 2</div>
          </div>
        </div>
      </div>

      {/* Game Controls */}
      <div className="flex gap-3">
        <button
          onClick={resetGame}
          className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-semibold py-3 px-6 rounded-xl
                   hover:from-blue-600 hover:to-indigo-700 transition-all duration-200 shadow-lg hover:shadow-xl
                   hover:scale-105 flex items-center justify-center gap-2"
        >
          <RotateCcw size={18} />
          New Game
        </button>
        <button
          onClick={resetScores}
          className="bg-gradient-to-r from-gray-500 to-gray-600 text-white font-semibold py-3 px-6 rounded-xl
                   hover:from-gray-600 hover:to-gray-700 transition-all duration-200 shadow-lg hover:shadow-xl
                   hover:scale-105 flex items-center justify-center gap-2"
        >
          <Trophy size={18} />
          Reset
        </button>
      </div>
    </div>
  );
}