import React from 'react';

interface EmojiPickerProps {
  title: string;
  selectedEmoji: string;
  onEmojiSelect: (emoji: string) => void;
  color: string;
}

const POPULAR_EMOJIS = [
  '😀', '😂', '🥳', '😎', '🤖', '👾', '🔥', '⭐',
  '🎯', '🚀', '💎', '👑', '🦄', '🐱', '🐶', '🐼',
  '🎨', '🎭', '🎪', '🎸', '⚡', '🌟', '💫', '🌈',
  '🍕', '🍰', '🎂', '🍭', '🧊', '❄️', '🌺', '🌸'
];

export default function EmojiPicker({ title, selectedEmoji, onEmojiSelect, color }: EmojiPickerProps) {
  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg border border-white/20">
      <h3 className={`text-lg font-semibold mb-3 text-center text-${color}-600`}>
        {title}
      </h3>
      
      {/* Current Selection */}
      <div className="text-center mb-4">
        <div className={`inline-block p-3 bg-gradient-to-br from-${color}-50 to-${color}-100 
                        rounded-full border-2 border-${color}-200`}>
          <span className="text-3xl">{selectedEmoji}</span>
        </div>
      </div>

      {/* Emoji Grid */}
      <div className="grid grid-cols-8 gap-2 max-h-40 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
        {POPULAR_EMOJIS.map((emoji, index) => (
          <button
            key={index}
            onClick={() => onEmojiSelect(emoji)}
            className={`
              aspect-square flex items-center justify-center text-xl rounded-lg
              transition-all duration-200 hover:scale-110
              ${selectedEmoji === emoji 
                ? `bg-gradient-to-br from-${color}-100 to-${color}-200 border-2 border-${color}-400 scale-110` 
                : 'bg-gray-50 hover:bg-gray-100 border border-gray-200'
              }
            `}
          >
            {emoji}
          </button>
        ))}
      </div>

      {/* Custom Emoji Input */}
      <div className="mt-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Or enter any emoji:
        </label>
        <input
          type="text"
          value={selectedEmoji}
          onChange={(e) => {
            const value = e.target.value;
            if (value.length <= 2) { // Allow emoji combinations
              onEmojiSelect(value);
            }
          }}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 
                     focus:border-transparent text-center text-xl"
          placeholder="😀"
          maxLength={2}
        />
      </div>
    </div>
  );
}