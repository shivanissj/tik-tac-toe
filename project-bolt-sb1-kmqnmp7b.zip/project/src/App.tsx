import React, { useState } from 'react';
import TicTacToe from './components/TicTacToe';
import EmojiPicker from './components/EmojiPicker';
import { Gamepad2, Settings, X } from 'lucide-react';

function App() {
  const [player1Emoji, setPlayer1Emoji] = useState('😀');
  const [player2Emoji, setPlayer2Emoji] = useState('😎');
  const [showSettings, setShowSettings] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 p-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Gamepad2 className="text-white" size={40} />
            <h1 className="text-4xl md:text-5xl font-bold text-white drop-shadow-lg">
              Emoji Tic Tac Toe
            </h1>
          </div>
          <p className="text-white/90 text-lg max-w-2xl mx-auto">
            Customize your game pieces with any emoji and challenge your friends!
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8 items-start">
          {/* Game Area */}
          <div className="flex-1 flex justify-center">
            <TicTacToe player1Emoji={player1Emoji} player2Emoji={player2Emoji} />
          </div>

          {/* Settings Panel */}
          <div className="w-full lg:w-80">
            <div className="lg:sticky lg:top-4">
              {/* Settings Toggle for Mobile */}
              <div className="lg:hidden mb-4">
                <button
                  onClick={() => setShowSettings(!showSettings)}
                  className="w-full bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg border border-white/20
                           flex items-center justify-center gap-2 text-gray-800 font-semibold
                           hover:bg-white/95 transition-all duration-200"
                >
                  <Settings size={20} />
                  {showSettings ? 'Hide Settings' : 'Customize Players'}
                  {showSettings && <X size={16} />}
                </button>
              </div>

              {/* Settings Content */}
              <div className={`space-y-6 ${showSettings ? 'block' : 'hidden lg:block'}`}>
                <EmojiPicker
                  title="Player 1"
                  selectedEmoji={player1Emoji}
                  onEmojiSelect={setPlayer1Emoji}
                  color="blue"
                />
                <EmojiPicker
                  title="Player 2"
                  selectedEmoji={player2Emoji}
                  onEmojiSelect={setPlayer2Emoji}
                  color="red"
                />

                {/* Game Instructions */}
                <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg border border-white/20">
                  <h3 className="text-lg font-semibold mb-3 text-gray-800">How to Play</h3>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li className="flex items-start gap-2">
                      <span className="text-blue-500 font-semibold">1.</span>
                      Choose your favorite emojis for each player
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-blue-500 font-semibold">2.</span>
                      Click on empty squares to place your emoji
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-blue-500 font-semibold">3.</span>
                      Get three in a row to win!
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-blue-500 font-semibold">4.</span>
                      Track your wins and play again
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-12 text-white/70">
          <p>Built with React + TypeScript + Tailwind CSS</p>
        </div>
      </div>
    </div>
  );
}

export default App;